﻿// See https://aka.ms/new-console-template for more information
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Extensions.ManagedClient;
using MQTTnet.Packets;
using System.Text;
using System.Configuration;
using Ttn.Library;
using Parser;
using Parser.SensorReadings;
using System.Collections;



public class Program
{
    private static readonly bool CONTAINER = false;

    /// <summary>
    /// MQTTnet usage: https://blog.behroozbc.ir/mqtt-client-with-mqttnet-4-and-c
    /// </summary>
    static async Task Main(string[] args)
    {
        Console.WriteLine($"{Environment.NewLine}" +
            $"MQTTnet ConsoleApp - A The Things Network V3 C# App {Environment.NewLine}");

        var TTN_APP_ID = "1118";
        var TTN_API_KEY = "NNSXS.NHG2JSLKILDSELHDPFCLSPQKQC7GBWQO3UQ7V5A.XIADRFQNIXC5ZFBQ5PWRPOGJHMECLQBO4S7AYQTXBW56JSDNJC3A";
        var TTN_REGION = "eu1";
        var TTN_BROKER = $"{TTN_REGION}.cloud.thethings.network";
        var TOPIC = "v3/+/devices/+/up";

        IManagedMqttClient _mqttClient = new MqttFactory().CreateManagedMqttClient();

        // Create client options object with keep alive 1 sec
        var builder = new MqttClientOptionsBuilder()
                        .WithTcpServer(TTN_BROKER, 1883)
                        .WithCredentials(TTN_APP_ID, TTN_API_KEY)
                        .WithCleanSession(true)
                        .WithKeepAlivePeriod(TimeSpan.FromSeconds(1));

        // auto reconnect after 5 sec if disconnected
        var options = new ManagedMqttClientOptionsBuilder()
               .WithAutoReconnectDelay(TimeSpan.FromSeconds(5))
               .WithClientOptions(builder.Build())
               .Build();

        // Set up handlers
        _mqttClient.ApplicationMessageReceivedAsync += MqttOnNewMessageAsync;
        _mqttClient.ConnectedAsync += MqttOnConnectedAsync;
        _mqttClient.DisconnectedAsync += MqttOnDisconnectedAsync;
        _mqttClient.ConnectingFailedAsync += MqttConnectingFailedAsync;

        var topics = new List<MqttTopicFilter>();
        var opts = new MqttTopicFilterBuilder()
            .WithTopic(TOPIC)
            .Build();
        topics.Add(opts);
        await _mqttClient.SubscribeAsync(topics);
        await _mqttClient.StartAsync(options);

        if (CONTAINER)
        {
            // use for testing when running as container
            Thread.Sleep(Timeout.Infinite);
        }
        else
        {
            Console.WriteLine("Press return to exit!");
            Console.ReadLine();
            Console.WriteLine("\nAloha, Goodbye, Vaarwel!");
            Thread.Sleep(1000);
        }
    }


    public static Task MqttOnNewMessageAsync(MqttApplicationMessageReceivedEventArgs eArg)
    {
        var obj = eArg.ApplicationMessage;
        var ttn = TtnMessage.DeserialiseMessageV3(obj);
        var data = ttn.Payload != null ? BitConverter.ToString(ttn.Payload) : string.Empty;

        // Own hex string payload decoder
        // var output = DecodeHexString(data);

        Console.WriteLine($"Timestamp: {ttn.Timestamp}, Device: {ttn.DeviceID}, \nTopic: {ttn.Topic}, \nPayload: {data}");

        // Own decoder for float values in example
        // string output = DecodeAndPrintValues(data);

        // Console.WriteLine(output);

        // CayenneLPP
        var cayenneDecodedValues = DecodeCayennePayload(data);
        Console.WriteLine($"Decoded Cayenne Payload: {cayenneDecodedValues}");

        return Task.CompletedTask;
    }



    // Add a new method to decode Cayenne Payload
    public static string DecodeCayennePayload(string payload)
    {
        try
        {
            byte[] byteArray = ConvertHexStringToByteArray(payload);
            var sensorReadings = SensorReadingParser.Parse(byteArray);

            StringBuilder decodedValues = new StringBuilder();

            foreach (var reading in sensorReadings)
            {
                string sensorInfo = string.Empty;

                switch (reading)
                {
                    case TemperatureSensor temperatureSensor:
                        sensorInfo += $"Temperature: {temperatureSensor.Temperature} °C, ";
                        break;
                    case AnalogOutput analogOutput:
                        sensorInfo += $"Led: {analogOutput.Value}, ";
                        break;
                    case HumiditySensor humiditySensor:
                        sensorInfo += $"Humidity: {humiditySensor.Humidity}%, ";
                        break;
                    case GpsLocation gpsLocation:
                        sensorInfo += $"\nLatitude: {gpsLocation.Latitude}, Longitude: {gpsLocation.Longitude}, Altitude: {gpsLocation.Altitude}";
                        break;
                }

                decodedValues.Append(sensorInfo);
            }

            return decodedValues.ToString();
        }
        catch (Exception ex)
        {
            return $"Error decoding Cayenne payload: {ex.Message}";
        }
    }


    public static string DecodeAndPrintValues(string payload)
    {
        try
        {
            // Convert the hex string to byte array
            byte[] byteArray = ConvertHexStringToByteArray(payload);

            // Ensure correct endianness (assuming big-endian)
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(byteArray);
            }

            // Extract float values from the byte array
            float ledValue = BitConverter.ToSingle(byteArray, 0);
            float humidity = BitConverter.ToSingle(byteArray, 4);
            float temperature = BitConverter.ToSingle(byteArray, 8);

            // Print the decoded values
            return $"Float Payload Converted To: Temperature: {temperature:F2}, Humidity: {humidity:F1}, Led: {ledValue:F1}";

        }
        catch (Exception ex)
        {
            return $"Error decoding payload: {ex.Message}";
        }
    }

    static byte[] ConvertHexStringToByteArray(string hexString)
    {
        // Remove hyphens and convert the hex string to byte array
        hexString = hexString.Replace("-", "");
        byte[] byteArray = new byte[hexString.Length / 2];

        for (int i = 0; i < byteArray.Length; i++)
        {
            byteArray[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
        }

        return byteArray;
    }

    public static string DecodeHexString(string hexString)
    {
        if (string.IsNullOrEmpty(hexString))
        {
            var message = $"There is no value in the string: '{hexString}'.";
            throw new NullReferenceException(message);

        }
        string decodedString = Encoding.ASCII.GetString(ConvertHexStringToByteArray(hexString));

        return decodedString;
    }

    private static Task MqttOnConnectedAsync(MqttClientConnectedEventArgs eArg)
    {
        Console.WriteLine($"MQTTnet Client -> Connected with result: {eArg.ConnectResult.ResultCode}");
        return Task.CompletedTask;
    }
    private static Task MqttOnDisconnectedAsync(MqttClientDisconnectedEventArgs eArg)
    {
        Console.WriteLine($"MQTTnet Client -> Connection lost! Reason: {eArg.Reason}");
        return Task.CompletedTask;
    }
    private static Task MqttConnectingFailedAsync(ConnectingFailedEventArgs eArg)
    {
        Console.WriteLine($"MQTTnet Client -> Connection failed! Reason: {eArg.Exception}");
        return Task.CompletedTask;
    }
}