using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parser.SensorReadings;
using Parser;

public class PayloadDecoderTests
{

    [Fact]
    public void HexToAscii_ShouldThrowException_WhenUsingNullInput()
    {
        Assert.Throws<NullReferenceException>(() => Program.DecodeHexString(null));
    }

    [Fact]
    public void HexToAscii_ShouldThrowException_WhenUsingEmptyInput()
    {
        Assert.Throws<NullReferenceException>(() => Program.DecodeHexString(""));
    }

    [Theory]
    [InlineData("48656C6C6F", "Hello")]
    [InlineData("4A6F686E", "John")]  
    [InlineData("54657374696E6720746865206465636F64656420537472696E67", "Testing the decoded String")]
    public void DecodeHexStringCharacters_ValidInput_ShouldReturnDecodedString(string hexInput, string expectedOutput)
    {
       
        var result = Program.DecodeHexString(hexInput);

        Assert.Equal(expectedOutput, result);
    }
   

    [Fact]
    public void DecodeAndPrintValues_ConvertsHexStringToFloatValues()
    {
        var hexString = "40490FDB40466666C05EBA6E";

        var result = Program.DecodeAndPrintValues(hexString);

        Assert.Contains("Float Payload Converted To: Temperature: 3.14, Humidity: 3.1, Led: -3.5", result);
    }



    [Theory]
    [InlineData("01-67-01-10-02-68-81-03-03-00-28-04-88-09-3A-C8-59-EF-00-3A-98-05", "Temperature: 27.2 �C, Humidity: 0.645%, Led: 0.40, \nLatitude: 60.4872, Longitude: 589.3888, Altitude: 38400.05")]
    public void DecodeCayennePayload_ValidInput_ShouldReturnDecodedValues(string payload, string expectedOutput)
    {
  
        var result = Program.DecodeCayennePayload(payload);

        Assert.Equal(expectedOutput, result);
    }

    [Fact]
    public void Parse_TemperatureSensorReadings_Success()
    {
        string hex = "01670210";

        IReadOnlyList<ISensorReading> list = SensorReadingParser.Parse(hex);

        Assert.IsType<List<ISensorReading>>(list);

        var result = (TemperatureSensor)list[0];

        Assert.Equal(1, result.Channel);
        Assert.Equal(0x67, result.Type);
        Assert.Equal(52.8m, result.Temperature);
    }

    [Fact]
    public void Parse_HumiditySensorReadings_Success()
    {
        string hex = "026892";

        IReadOnlyList<ISensorReading> list = SensorReadingParser.Parse(hex);

        Assert.IsType<List<ISensorReading>>(list);

        var result = (HumiditySensor)list[0];

        Assert.Equal(2, result.Channel);
        Assert.Equal(0x68, result.Type);
        Assert.Equal(0.730m, result.Humidity);
    }

    [Fact]
    public void Parse_AnalogOutputSensorReadings_Success()
    {
        string hex = "03030028";

        IReadOnlyList<ISensorReading> list = SensorReadingParser.Parse(hex);

        Assert.IsType<List<ISensorReading>>(list);

        var result = (AnalogOutput)list[0];

        Assert.Equal(3, result.Channel);
        Assert.Equal(0x03, result.Type);
        Assert.Equal(0.40m, result.Value);
    }

    [Fact]
    public void Parse_GpsLocationSensorReadings_Success()
    {
        string hex = "048809803ff1200a0002f4";

        IReadOnlyList<ISensorReading> list = SensorReadingParser.Parse(hex);

        Assert.IsType<List<ISensorReading>>(list);

        var result = (GpsLocation)list[0];

        Assert.Equal(4, result.Channel);
        Assert.Equal(0x88, result.Type);
        Assert.Equal(62.2655m, result.Latitude);
        Assert.Equal(-97.4838m, result.Longitude);
        Assert.Equal(7.56m, result.Altitude);
    }
}
